// import "@hotwired/turbo-rails"
// import "controllers"



// app/javascript/controllers/application.js

import "@hotwired/turbo-rails"

import { Application } from "@hotwired/stimulus"


const application = Application.start()
window.Stimulus = application
;
