// @hotwired/turbo-rails@2.1.0 downloaded from https://ga.jspm.io/npm:@jspm/core@2.1.0/nodelibs/@empty.js

var e=Object.freeze(Object.create(null));export{e as default};

