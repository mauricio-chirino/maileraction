// config/manifest.js


;
