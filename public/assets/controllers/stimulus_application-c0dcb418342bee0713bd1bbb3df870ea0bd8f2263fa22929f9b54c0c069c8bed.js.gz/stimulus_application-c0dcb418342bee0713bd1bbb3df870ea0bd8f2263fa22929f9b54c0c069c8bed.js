// app/javascript/stimulus_application.js
import { Application } from "@hotwired/stimulus"

const application = Application.start()

// Carga automática de todos los controladores




export { application };
