// app/javascript/controllers/index.js
import { application } from "application"

// import BootstrapController from "bootstrap_controller"

import DragController from "drag_controller"
import DropController from "drop_controller"





import DatatableController from "controllers/datatable_controller"
import ResponsiveController from "controllers/responsive_controller"
import MapController from "controllers/map_controller"
import BootstrapController from "controllers/bootstrap_controller"



// application.register("bootstrap", BootstrapController)

application.register("drag", DragController)
application.register("drop", DropController)



application.register("datatable", DatatableController)
application.register("responsive", ResponsiveController)
application.register("map", MapController)
application.register("bootstrap", BootstrapController);
