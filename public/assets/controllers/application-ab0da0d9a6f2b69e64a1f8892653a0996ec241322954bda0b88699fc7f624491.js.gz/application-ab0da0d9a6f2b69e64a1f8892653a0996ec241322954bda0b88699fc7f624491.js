import { Application } from "@hotwired/stimulus"

export const application = Application.start();
