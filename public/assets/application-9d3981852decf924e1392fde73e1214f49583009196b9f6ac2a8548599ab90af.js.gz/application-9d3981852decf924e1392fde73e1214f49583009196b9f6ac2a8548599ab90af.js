// Configure your import map in config/importmap.rb. Read more: https://github.com/rails/importmap-rails
// app/javascript/application.js

import "@hotwired/turbo-rails"
import "./stimulus_application" // <- Este importa y arranca Stimulus
import "controllers"
//import "bootstrap"
import "./global_helpers"


;
